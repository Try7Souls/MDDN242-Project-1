document.getElementById("myButton").addEventListener("click", () => {
  alert("Button clicked!");
});
